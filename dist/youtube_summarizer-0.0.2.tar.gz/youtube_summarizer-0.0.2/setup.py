from setuptools import setup

setup(
    name='youtube_summarizer',
    version='0.0.2',
    author='Isaac Duong',
    author_email='isaaacduong@gmail.com',
    description=("Python script to extract video transcripts" 
                 "based on the video id, and summarize the" 
                 "text content using the GPT-3.5 Turbo model"),
    packages=['yt_summarizer'],
   
)
